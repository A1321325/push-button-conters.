import React, { useState, useEffect } from 'react';

interface PushButtonProps {
  onPress: () => void;
  debouncing: boolean;
}

const PushButton: React.FC<PushButtonProps> = ({ onPress, debouncing }) => {
  const [isPressed, setIsPressed] = useState(false);
  const [pressAnimation, setPressAnimation] = useState(false);
  
  // Handle button press animation
  const handleButtonDown = () => {
    if (debouncing) return;
    setIsPressed(true);
    setPressAnimation(true);
  };
  
  // Handle button release
  const handleButtonUp = () => {
    if (debouncing) return;
    setIsPressed(false);
    
    // Only trigger onPress when button is released
    if (pressAnimation) {
      onPress();
    }
  };
  
  // Reset animation state
  useEffect(() => {
    if (pressAnimation) {
      const timeout = setTimeout(() => {
        setPressAnimation(false);
      }, 200);
      
      return () => clearTimeout(timeout);
    }
  }, [pressAnimation]);
  
  return (
    <div className="flex flex-col items-center">
      <div className="relative">
        {/* Button base */}
        <div className="w-20 h-6 bg-gray-700 rounded-b-lg"></div>
        
        {/* Button housing */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-full">
          <div 
            className={`
              relative
              w-24 h-24 
              rounded-full 
              ${debouncing ? 'bg-amber-500' : 'bg-red-700'} 
              shadow-lg
              transition-all duration-200
              ${isPressed ? 'scale-95' : 'scale-100'}
              cursor-pointer
              select-none
            `}
            onMouseDown={handleButtonDown}
            onMouseUp={handleButtonUp}
            onMouseLeave={() => isPressed && handleButtonUp()}
            onTouchStart={handleButtonDown}
            onTouchEnd={handleButtonUp}
          >
            {/* Button surface */}
            <div 
              className={`
                absolute 
                top-2 left-2 
                w-20 h-20 
                rounded-full 
                ${debouncing ? 'bg-amber-600' : 'bg-red-600'} 
                flex items-center justify-center
                transition-all duration-100
                ${isPressed ? 'shadow-inner' : 'shadow-md'}
              `}
            >
              {/* Button label */}
              <span className="text-white font-bold text-sm">PUSH</span>
            </div>
            
            {/* Button press animation ring */}
            {pressAnimation && !debouncing && (
              <div className="absolute inset-0 rounded-full animate-ping-once border-2 border-white opacity-70"></div>
            )}
            
            {/* Debouncing indicator */}
            {debouncing && (
              <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-amber-500 text-white text-xs px-2 py-1 rounded">
                Debouncing...
              </div>
            )}
          </div>
        </div>
      </div>
      
      <p className="mt-28 text-sm text-slate-400">Click to press button</p>
    </div>
  );
};

export default PushButton;