import React, { useState, useEffect, useRef } from 'react';
import CircuitDiagram from './CircuitDiagram';
import LCDDisplay from './LCDDisplay';
import PushButton from './PushButton';
import SerialMonitor from './SerialMonitor';
import CodeSnippet from './CodeSnippet';
import { Clock, RefreshCw, Info } from 'lucide-react';

const ButtonCounter: React.FC = () => {
  const [count, setCount] = useState<number>(0);
  const [lastPressTime, setLastPressTime] = useState<number | null>(null);
  const [debouncing, setDebouncing] = useState<boolean>(false);
  const [serialMessages, setSerialMessages] = useState<string[]>([
    "System initialized. Ready for input.",
  ]);
  const serialRef = useRef<HTMLDivElement>(null);
  
  // Reset counter function
  const resetCounter = () => {
    setCount(0);
    addSerialMessage("Counter reset to 0");
  };
  
  const addSerialMessage = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setSerialMessages(prev => [...prev, `[${timestamp}] ${message}`]);
  };

  // Effect to scroll serial monitor to bottom when new messages arrive
  useEffect(() => {
    if (serialRef.current) {
      serialRef.current.scrollTop = serialRef.current.scrollHeight;
    }
  }, [serialMessages]);

  // Handle button press with debouncing
  const handleButtonPress = () => {
    const now = Date.now();
    
    // Check if we should ignore this press (debouncing)
    if (lastPressTime && now - lastPressTime < 300) {
      setDebouncing(true);
      addSerialMessage("Debounce detected - ignoring press");
      
      // Reset debouncing visual after delay
      setTimeout(() => {
        setDebouncing(false);
      }, 300);
      
      return;
    }
    
    // Valid press - increment counter
    setCount(prev => prev + 1);
    setLastPressTime(now);
    addSerialMessage(`Button pressed - Count incremented to ${count + 1}`);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 py-6">
      <div className="bg-slate-800 rounded-lg p-6 shadow-lg">
        <h2 className="text-xl font-bold mb-4 flex items-center">
          <span className="mr-2">Interactive Simulation</span>
          <div className="relative group">
            <Info size={16} className="text-slate-400 cursor-help" />
            <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-64 p-2 bg-slate-700 rounded shadow-lg text-xs hidden group-hover:block z-10">
              This simulation demonstrates how a microcontroller handles button input with debouncing.
            </div>
          </div>
        </h2>
        
        <div className="space-y-6">
          <div className="bg-slate-700 p-4 rounded-lg">
            <LCDDisplay count={count} />
          </div>
          
          <div className="flex justify-center">
            <PushButton 
              onPress={handleButtonPress} 
              debouncing={debouncing}
            />
            
            <button 
              onClick={resetCounter}
              className="ml-4 flex items-center bg-slate-600 hover:bg-slate-500 text-white rounded-md px-3 py-2 transition-colors"
            >
              <RefreshCw size={16} className="mr-1" />
              Reset
            </button>
          </div>
          
          <div className="bg-slate-700 p-4 rounded-lg">
            <h3 className="text-md font-semibold mb-2 flex items-center">
              <Clock size={16} className="mr-1" />
              Serial Monitor Output
            </h3>
            <SerialMonitor messages={serialMessages} ref={serialRef} />
          </div>
        </div>
      </div>
      
      <div className="bg-slate-800 rounded-lg p-6 shadow-lg">
        <h2 className="text-xl font-bold mb-4">Circuit Diagram</h2>
        <CircuitDiagram />
        
        <h2 className="text-xl font-bold mt-8 mb-4">Implementation Details</h2>
        <div className="space-y-6">
          <div>
            <h3 className="text-md font-semibold mb-2">Arduino Code Implementation</h3>
            <CodeSnippet language="arduino" />
          </div>
          
          <div>
            <h3 className="text-md font-semibold mb-2">Button Debouncing Explanation</h3>
            <p className="text-slate-300 text-sm leading-relaxed">
              When a physical button is pressed, it often creates multiple electrical signals due to mechanical bouncing. 
              Debouncing is a technique to ensure a single button press is counted only once by ignoring signals that occur 
              within a short time window (typically 20-300ms) after the initial press.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ButtonCounter;