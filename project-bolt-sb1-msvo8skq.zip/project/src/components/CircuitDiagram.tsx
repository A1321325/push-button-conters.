import React from 'react';

const CircuitDiagram: React.FC = () => {
  return (
    <div className="bg-slate-700 p-4 rounded-lg overflow-auto">
      <svg
        viewBox="0 0 600 300"
        className="w-full h-auto"
        style={{ minWidth: '500px' }}
      >
        {/* Grid lines for reference */}
        <g opacity="0.1" stroke="white" strokeWidth="0.5">
          {Array.from({ length: 30 }).map((_, i) => (
            <line key={`vl-${i}`} x1={i * 20} y1="0" x2={i * 20} y2="300" />
          ))}
          {Array.from({ length: 15 }).map((_, i) => (
            <line key={`hl-${i}`} x1="0" y1={i * 20} x2="600" y2={i * 20} />
          ))}
        </g>

        {/* Microcontroller (Arduino) */}
        <g className="microcontroller">
          <rect x="240" y="100" width="160" height="100" rx="5" fill="#0F4C81" stroke="white" strokeWidth="2" />
          <text x="320" y="140" textAnchor="middle" fill="white" fontSize="14" fontWeight="bold">ARDUINO UNO</text>
          <text x="320" y="160" textAnchor="middle" fill="white" fontSize="12">ATmega328P</text>
          
          {/* Pins */}
          <rect x="240" y="120" width="10" height="10" fill="gold" />
          <text x="235" y="130" textAnchor="end" fill="white" fontSize="10">5V</text>
          
          <rect x="240" y="140" width="10" height="10" fill="black" />
          <text x="235" y="150" textAnchor="end" fill="white" fontSize="10">GND</text>
          
          <rect x="240" y="160" width="10" height="10" fill="#4CAF50" />
          <text x="235" y="170" textAnchor="end" fill="white" fontSize="10">D2</text>
          
          <rect x="390" y="120" width="10" height="10" fill="#9C27B0" />
          <text x="405" y="130" textAnchor="start" fill="white" fontSize="10">D12</text>
          
          <rect x="390" y="140" width="10" height="10" fill="#2196F3" />
          <text x="405" y="150" textAnchor="start" fill="white" fontSize="10">D11</text>
          
          <rect x="390" y="160" width="10" height="10" fill="#FF9800" />
          <text x="405" y="170" textAnchor="start" fill="white" fontSize="10">D10</text>
        </g>

        {/* Push Button */}
        <g className="push-button">
          <rect x="120" y="150" width="40" height="40" rx="5" fill="#E63946" stroke="white" strokeWidth="2" />
          <circle cx="140" cy="170" r="15" fill="#B1000E" stroke="white" strokeWidth="1" />
          <text x="140" y="210" textAnchor="middle" fill="white" fontSize="12">BUTTON</text>
        </g>

        {/* LCD Display */}
        <g className="lcd-display">
          <rect x="440" y="140" width="100" height="60" rx="2" fill="#2A9D8F" stroke="white" strokeWidth="2" />
          <rect x="450" y="150" width="80" height="30" fill="#072E2B" stroke="#4CAF50" strokeWidth="1" />
          <text x="490" y="170" textAnchor="middle" fill="#4CAF50" fontSize="14" fontFamily="monospace">00</text>
          <text x="490" y="220" textAnchor="middle" fill="white" fontSize="12">LCD DISPLAY</text>
        </g>

        {/* Resistor for button */}
        <g className="resistor">
          <line x1="160" y1="170" x2="180" y2="170" stroke="white" strokeWidth="2" />
          <path d="M180,170 L200,170" stroke="white" strokeWidth="2" />
          <rect x="200" y="165" width="20" height="10" fill="#FF9800" stroke="white" strokeWidth="1" />
          <text x="210" y="185" textAnchor="middle" fill="white" fontSize="8">10kΩ</text>
          <path d="M220,170 L240,170" stroke="white" strokeWidth="2" />
        </g>

        {/* LCD Connections */}
        <g className="lcd-connections">
          <path d="M400,120 L420,120 L420,140 L440,140" stroke="#9C27B0" strokeWidth="2" fill="none" />
          <path d="M400,140 L420,140 L440,160" stroke="#2196F3" strokeWidth="2" fill="none" />
          <path d="M400,160 L420,160 L420,180 L440,180" stroke="#FF9800" strokeWidth="2" fill="none" />
        </g>

        {/* Button to Arduino Connection */}
        <path d="M120,170 L100,170 L100,200 L260,200 L260,160 L250,160" stroke="#4CAF50" strokeWidth="2" fill="none" />

        {/* Power and Ground connections */}
        <path d="M240,120 L220,120 L220,100 L440,100 L440,140" stroke="gold" strokeWidth="2" fill="none" />
        <path d="M240,140 L220,140 L220,200 L440,200 L440,180" stroke="black" strokeWidth="2" fill="none" />

        {/* Legend */}
        <g className="legend" transform="translate(100, 250)">
          <rect x="0" y="0" width="400" height="40" rx="5" fill="rgba(0,0,0,0.3)" />
          
          <circle cx="20" cy="10" r="5" fill="gold" />
          <text x="30" y="13" fill="white" fontSize="10">5V Power</text>
          
          <circle cx="100" cy="10" r="5" fill="black" />
          <text x="110" y="13" fill="white" fontSize="10">Ground</text>
          
          <circle cx="180" cy="10" r="5" fill="#4CAF50" />
          <text x="190" y="13" fill="white" fontSize="10">Digital Input</text>
          
          <circle cx="280" cy="10" r="5" fill="#2196F3" />
          <text x="290" y="13" fill="white" fontSize="10">LCD Control</text>
          
          <rect x="20" y="25" width="10" height="5" fill="#FF9800" />
          <text x="35" y="30" fill="white" fontSize="10">Resistor</text>
          
          <rect x="100" y="25" width="10" height="5" fill="#E63946" />
          <text x="115" y="30" fill="white" fontSize="10">Button</text>
          
          <rect x="180" y="25" width="10" height="5" fill="#0F4C81" />
          <text x="195" y="30" fill="white" fontSize="10">Microcontroller</text>
          
          <rect x="280" y="25" width="10" height="5" fill="#2A9D8F" />
          <text x="295" y="30" fill="white" fontSize="10">LCD Display</text>
        </g>
      </svg>
    </div>
  );
};

export default CircuitDiagram;