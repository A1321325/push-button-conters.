import React from 'react';

interface LCDDisplayProps {
  count: number;
}

const LCDDisplay: React.FC<LCDDisplayProps> = ({ count }) => {
  // Format count to always show at least 2 digits
  const formattedCount = count.toString().padStart(2, '0');
  
  return (
    <div className="relative">
      <div className="bg-black border-4 border-gray-700 rounded-md p-4 max-w-xs mx-auto">
        <div className="bg-[#072b13] p-3 font-mono text-center relative overflow-hidden">
          {/* LCD Glare Effect */}
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-[#1c522d]/10 to-transparent pointer-events-none"></div>
          
          {/* LCD Header */}
          <div className="text-[#4CAF50] text-xs mb-2 font-bold border-b border-[#4CAF50]/30 pb-1">
            BUTTON PRESS COUNTER
          </div>
          
          {/* Count Display */}
          <div className="flex justify-between items-center px-2">
            <div className="text-[#4CAF50] text-sm">Count:</div>
            <div className="text-[#4CAF50] text-2xl font-bold tracking-widest">
              {formattedCount}
            </div>
          </div>
          
          {/* LCD Footer with "pixels" */}
          <div className="mt-3 flex justify-between">
            {Array.from({ length: 16 }).map((_, i) => (
              <div 
                key={i}
                className={`h-1 w-1 rounded-full ${
                  i % 3 === 0 ? 'bg-[#4CAF50]/80' : 'bg-[#4CAF50]/20'
                }`}
              ></div>
            ))}
          </div>
        </div>
      </div>
      
      {/* LCD Connector */}
      <div className="h-3 w-12 bg-gray-700 absolute -bottom-3 left-1/2 transform -translate-x-1/2"></div>
    </div>
  );
};

export default LCDDisplay;