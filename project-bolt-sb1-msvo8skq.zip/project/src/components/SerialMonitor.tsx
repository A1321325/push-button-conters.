import React, { forwardRef } from 'react';

interface SerialMonitorProps {
  messages: string[];
}

const SerialMonitor = forwardRef<HTMLDivElement, SerialMonitorProps>(
  ({ messages }, ref) => {
    return (
      <div 
        ref={ref}
        className="bg-black font-mono text-green-500 p-3 rounded h-32 overflow-y-auto text-xs"
      >
        {messages.map((message, index) => (
          <div key={index} className="mb-1">
            {message}
          </div>
        ))}
        <div className="h-3"></div> {/* Space at the bottom for better scrolling */}
      </div>
    );
  }
);

SerialMonitor.displayName = 'SerialMonitor';

export default SerialMonitor;