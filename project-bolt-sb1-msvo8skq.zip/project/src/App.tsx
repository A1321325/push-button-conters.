import React from 'react';
import ButtonCounter from './components/ButtonCounter';
import './index.css';

function App() {
  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <header className="p-4 bg-slate-800 border-b border-slate-700">
        <div className="container mx-auto">
          <h1 className="text-2xl font-bold text-center">Microcontroller Button Counter Simulation</h1>
          <p className="text-center text-slate-400 mt-1">Learn about embedded systems, button debouncing, and counter implementation</p>
        </div>
      </header>
      <main className="container mx-auto p-4">
        <ButtonCounter />
      </main>
      <footer className="p-4 border-t border-slate-700 text-center text-slate-400 text-sm">
        <p>© 2025 Embedded Systems Learning Platform</p>
      </footer>
    </div>
  );
}

export default App;